import os
import numpy as np
from tensorflow import keras
from tensorflow.keras.preprocessing import image # type: ignore

def load_model():
    """Load the trained Alzheimer detection model safely"""
    try:
        
        model_path = os.path.join(
            os.path.dirname(__file__), "ml_models", "alzheimer_disease_prediction_model (1).h5"
        )
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"Model file not found at {model_path}")

        model = keras.models.load_model(model_path, compile=False)
        return model
    except Exception as e:
        raise RuntimeError(f"Error loading model: {e}")


def preprocess_image(img_path, target_size=(224, 224)):
    """Preprocess MRI scan image for model prediction (RGB, resized)"""
    try:
        img = image.load_img(img_path, target_size=target_size, color_mode="rgb")
        img_array = image.img_to_array(img)
        img_array = img_array.astype("float32") / 255.0
        img_array = np.expand_dims(img_array, axis=0)
        return img_array
    except Exception as e:
        raise ValueError(f"Error preprocessing image: {e}")


# ======================
# ✅ Class names (same order as training)
# ======================
CLASS_NAMES = ['ModerateDemented','VeryMildDemented','NonDemented','MildDemented']


# ======================
# ✅ Class descriptions
# ======================
def get_class_description(class_name):
    """Map raw class names to user-friendly description"""
    descriptions = {
        "NonDemented": (
            "🧠 Non-Demented: No signs of dementia detected. Brain structure appears normal."
        ),
        "VeryMildDemented": (
            "🔍 Very Mild Demented: Very early stage of dementia detected. "
            "Symptoms are subtle but monitoring and regular checkups are advised."
        ),
        "MildDemented": (
            "⚠️ Mild Demented: Mild dementia detected. Patient may show memory and cognitive decline. "
            "Clinical evaluation is recommended."
        ),
        "ModerateDemented": (
            "🚨 Moderate Demented: Noticeable impairment in daily activities. "
            "Immediate medical attention and care are required."
        ),
    }
    return descriptions.get(class_name, "No description available.")
