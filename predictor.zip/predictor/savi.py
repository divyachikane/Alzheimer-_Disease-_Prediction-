from tensorflow.keras.models import load_model # type: ignore
model = load_model("predictor/ml_models/alzheimer_disease_prediction_model (1).h5")
model.input_shape
