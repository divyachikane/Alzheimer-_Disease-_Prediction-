import os
import numpy as np
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.conf import settings
from django.core.files.storage import default_storage

from .forms import CustomLoginForm, ImageUploadForm
from .models import PredictionHistory
from .ml_utils import load_model, preprocess_image, get_class_description, CLASS_NAMES

# Global model variable (lazy loading)
_model = None


def get_model():
    """Lazy load ML model"""
    global _model
    if _model is None:
        _model = load_model()
    return _model


def custom_login(request):
    """Custom login with redirect"""
    if request.user.is_authenticated:
        return redirect("predictor:home")

    if request.method == "POST":
        form = CustomLoginForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.success(request, f"Welcome back, {user.username}!")
                return redirect("predictor:home")
        else:
            messages.error(request, "Invalid username or password.")
    else:
        form = CustomLoginForm()

    return render(request, "predictor/login.html", {"form": form})


@login_required
def custom_logout(request):
    """Logout user and redirect to login"""
    logout(request)
    messages.success(request, "You have been logged out successfully.")
    return redirect("predictor:login")


@login_required
def home(request):
    """Home page with image upload"""
    form = ImageUploadForm()
    context = {
        "form": form,
        "user": request.user,
    }
    return render(request, "predictor/index.html", context)


def about(request):
    """About page"""
    return render(request, "predictor/about.html")


def model_info(request):
    """Model info page"""
    return render(request, "predictor/model.html")


def accuracy(request):
    """Accuracy page"""
    csv_path = os.path.join(settings.BASE_DIR, "predictor", "static", "data", "training_history.csv")
    has_csv = os.path.exists(csv_path)
    return render(request, "predictor/accuracy.html", {"has_training_data": has_csv})


@login_required
def predict(request):
    """Handle image prediction"""
    if request.method != "POST":
        return redirect("predictor:home")

    form = ImageUploadForm(request.POST, request.FILES)
    if not form.is_valid():
        messages.error(request, "Please select a valid image file.")
        return redirect("predictor:home")

    try:
        uploaded_image = request.FILES["image"]
        image_path = default_storage.save(f"uploads/{uploaded_image.name}", uploaded_image)
        preview_url = default_storage.url(image_path)
        full_image_path = os.path.join(settings.MEDIA_ROOT, image_path)

        processed_image = preprocess_image(full_image_path)

        model = get_model()
        if model is None:
            messages.error(request, "Model not available. Please contact administrator.")
            return redirect("predictor:home")

        # 🔮 Prediction
        prediction = model.predict(processed_image)
        predicted_class_idx = np.argmax(prediction[0])
        confidence = float(prediction[0][predicted_class_idx])

        # ✅ Dataset class names
        predicted_class = CLASS_NAMES[predicted_class_idx]
        description = get_class_description(predicted_class)

        # Save history
        PredictionHistory.objects.create(
            user=request.user,
            image=image_path,
            predicted_class=predicted_class,
            confidence=confidence,
        )

        # Send to template
        context = {
            "form": ImageUploadForm(),
            "prediction_made": True,
            "predicted_class": predicted_class,
            "confidence": confidence,
            "confidence_percent": f"{confidence * 100:.2f}",
            "description": description,
            "preview_url": preview_url,
            "user": request.user,
        }
        return render(request, "predictor/index.html", context)

    except Exception as e:
        messages.error(request, f"Error processing image: {str(e)}")
        return redirect("predictor:home")


@login_required
def payment(request):
    """
    Dummy payment page.
    Captures doctor name & fee from query parameters and shows payment form.
    """
    doctor = request.GET.get("doctor", "Unknown Doctor")
    fee = request.GET.get("fee", "N/A")

    context = {
        "doctor": doctor,
        "fee": fee,
    }
    return render(request, "predictor/payment.html", context)
