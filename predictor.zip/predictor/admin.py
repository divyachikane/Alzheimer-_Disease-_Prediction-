from django.contrib import admin
from .models import PredictionHistory, ModelVersion


@admin.register(PredictionHistory)
class PredictionHistoryAdmin(admin.ModelAdmin):
    list_display = ['user', 'predicted_class', 'confidence', 'created_at']
    list_filter = ['predicted_class', 'created_at']
    search_fields = ['user__username', 'predicted_class']
    readonly_fields = ['created_at']


@admin.register(ModelVersion)
class ModelVersionAdmin(admin.ModelAdmin):
    list_display = ['version', 'uploaded_by', 'uploaded_at', 'is_active']
    list_filter = ['is_active', 'uploaded_at']
    search_fields = ['version', 'uploaded_by__username']
    readonly_fields = ['uploaded_at']