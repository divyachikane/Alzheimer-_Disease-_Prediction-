from django.db import models
from django.contrib.auth.models import User


class PredictionHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    image = models.ImageField(upload_to='uploads/')
    predicted_class = models.CharField(max_length=50)
    confidence = models.FloatField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
        verbose_name_plural = "Prediction Histories"

    def __str__(self):
        return f"{self.user.username} - {self.predicted_class} ({self.confidence:.2%})"


class ModelVersion(models.Model):
    version = models.CharField(max_length=50)
    model_file = models.FileField(upload_to='models/')
    uploaded_by = models.ForeignKey(User, on_delete=models.CASCADE)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=False)
    
    class Meta:
        ordering = ['-uploaded_at']

    def __str__(self):
        return f"Model v{self.version} - {'Active' if self.is_active else 'Inactive'}"