from django.urls import path
from . import views

app_name = "predictor"

urlpatterns = [
    path("", views.home, name="home"),
    path("login/", views.custom_login, name="login"),
    path("logout/", views.custom_logout, name="logout"),
    path("about/", views.about, name="about"),
    path("model/", views.model_info, name="model_info"),   
    path("accuracy/", views.accuracy, name="accuracy"),
    path("predict/", views.predict, name="predict"),

    path("payment/", views.payment, name="payment"),
]

