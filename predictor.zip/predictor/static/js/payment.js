document.addEventListener("DOMContentLoaded", function () {
    const form = document.getElementById("paymentForm");
    const successMsg = document.getElementById("successMsg");

    form.addEventListener("submit", function (e) {
        e.preventDefault(); // normal form submit stop

        // Get form values
        let doctor = document.querySelector('input[readonly]').value;
        let name = form.querySelector('input[placeholder="Enter your name"]').value;
        let email = form.querySelector('input[placeholder="Enter your email"]').value;
        let phone = form.querySelector('input[placeholder="Enter your phone"]').value;

        // Razorpay test mode options
        var options = {
            "key": "rzp_test_1DP5mmOlF5G5ag", // ✅ Official Razorpay test key (error free)
            "amount": 100000, // paisa me (₹1000 = 100000)
            "currency": "INR",
            "name": doctor,
            "description": "Appointment Booking",
            "prefill": {
                "name": name,
                "email": email,
                "contact": phone
            },
            "handler": function (response) {
                 setTimeout(function () {
                // On successful payment
                successMsg.style.display = "block";
                form.style.display = "none";
                console.log("Payment Successful. ID:", response.razorpay_payment_id);
                }, 2000);
            },
            "theme": {
                "color": "#3399cc"
            }
        };

        var rzp1 = new Razorpay(options);
        rzp1.open();
    });
});
